[H[2J[3J[H[2J[3J
[5;36m┌──────────────────────────────────────────┐[0m
            Status Autokill [31m[OFF][0m           
[5;36m└──────────────────────────────────────────┘[0m
[5;36m┌──────────────────────────────────────────┐[0m
       1. AutoKill After 1 Minutes
       2. AutoKill After 2 Minutes
       3. AutoKill After 3 Minutes
       4. Turn Off AutoKill/MultiLogin
       5. Exit
[5;36m└──────────────────────────────────────────┘[0m


